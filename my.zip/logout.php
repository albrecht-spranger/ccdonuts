<?php
// /logout.php
declare(strict_types=1);
require_once __DIR__ . '/app/sessionManager.php';
require_once __DIR__ . '/app/commonFunctions.php';
$pageTitle = 'ログアウト | CC Donuts';
require 'header.php';
?>
<main class="container">
  <h2>ログアウト</h2>
  <p>ログアウトしますか？</p>
  <form action="app/logoutProcess.php" method="post">
    <input type="hidden" name="csrfToken" value="<?php echo h($_SESSION['csrfToken']); ?>">
    <button type="submit">ログアウト</button>
    <a href="index.php" class="button">キャンセル</a>
  </form>
</main>
<?php require 'footer.php'; ?>
