<?php
// /login.php
declare(strict_types=1);
require_once __DIR__ . '/app/sessionManager.php';
require_once __DIR__ . '/app/commonFunctions.php';

$pageTitle = 'ログイン | CC Donuts';
$err  = get_flash('error');
$done = get_flash('done');

require 'header.php';
?>
<main class="authPage loginPage">
  <nav class="breadcrumb" aria-label="breadcrumb">
    <span class="crumb current">ログイン</span>
    <span class="sep">＞</span><a href="index.php" class="crumb">TOP</a>
  </nav>

  <p class="greeting">ようこそ　ゲスト様</p>

  <h1 class="pageTitle">ログイン</h1>

  <?php if ($err): ?><p class="alert error"><?php echo h($err); ?></p><?php endif; ?>
  <?php if ($done): ?><p class="alert done"><?php echo h($done); ?></p><?php endif; ?>

  <form action="app/loginProcess.php" method="post" class="authForm" aria-label="ログインフォーム">
    <input type="hidden" name="csrfToken" value="<?php echo h($_SESSION['csrfToken']); ?>">

    <div class="formRow">
      <label for="login_mail">メールアドレス</label>
      <input id="login_mail" type="email" name="mail" required placeholder="example@domain.com">
    </div>

    <div class="formRow">
      <label for="login_password">パスワード</label>
      <input id="login_password" type="password" name="password" required placeholder="●●●●●●">
    </div>

    <div class="formActions">
      <button type="submit" class="btnPrimary">ログインする</button>
    </div>

    <p class="subLink">
      会員登録がまだの方は <a href="signup.php">会員登録はこちら</a>
    </p>
  </form>
</main>
<?php require 'footer.php'; ?>
