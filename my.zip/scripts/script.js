document.addEventListener("DOMContentLoaded", () => {
	console.log("ccdonuts loaded");
});